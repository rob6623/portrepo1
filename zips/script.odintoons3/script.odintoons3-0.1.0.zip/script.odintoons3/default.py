# -*- coding: utf-8 -*-
from lib.client import main

main() # See bottom of client.py.